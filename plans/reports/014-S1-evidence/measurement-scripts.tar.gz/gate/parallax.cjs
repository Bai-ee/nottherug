const L = require('./trace-lib.cjs');
const R = [];
(async () => {
  const browser = await L.chromium.launch();
  for (const variant of ['on', 'off']) {
    for (let run = 1; run <= 3; run++) {
      const { ctx, page, cdp } = await L.newPage(browser, { patchParallax: variant === 'off' });
      await cdp.send('Performance.enable');
      const m = async () => Object.fromEntries((await cdp.send('Performance.getMetrics')).metrics.map((x) => [x.name, x.value]));
      const tr = await L.startTrace(cdp);
      await page.goto(L.URL, { waitUntil: 'load' });
      await L.sleep(6000);
      const loadM = await m();
      const nArt = await page.evaluate(() => document.querySelectorAll('[data-city-parallax]').length);
      const nArt2 = await page.evaluate(() => document.querySelectorAll('[data-city-parallax-off]').length);
      // scroll measurement: rAF-driven, 8 px/frame, from 600 to 6600 px, 750 frames
      await page.evaluate(() => window.scrollTo(0, 600));
      await L.sleep(1500);
      const m0 = await m();
      const fr = await page.evaluate(() => new Promise((res) => {
        const d = []; let last = performance.now(), y = 600, n = 0;
        function step(t) { d.push(t - last); last = t; y += 8; window.scrollTo(0, y); if (++n < 750) requestAnimationFrame(step); else res(d); }
        requestAnimationFrame(step);
      }));
      const m1 = await m();
      await L.sleep(300);
      const ev = await tr.stop();
      const P = L.parse(ev);
      const frames = fr.slice(1);
      const d = (k) => (m1[k] - m0[k]) * 1000;
      const row = { variant, run, artEls: nArt, artElsPatched: nArt2, frames: frames.length,
        frameMsMean: +(frames.reduce((a, b) => a + b, 0) / frames.length).toFixed(2),
        gt20: frames.filter((x) => x > 20).length, gt33: frames.filter((x) => x > 33.4).length, gt16_7: frames.filter((x) => x > 16.7).length,
        scriptMsPerFrame: +(d('ScriptDuration') / frames.length).toFixed(3), layoutMsPerFrame: +(d('LayoutDuration') / frames.length).toFixed(3),
        styleMsPerFrame: +(d('RecalcStyleDuration') / frames.length).toFixed(3), taskMsPerFrame: +(d('TaskDuration') / frames.length).toFixed(3),
        loadScriptMs: +(loadM.ScriptDuration * 1000).toFixed(0), loadTaskMs: +(loadM.TaskDuration * 1000).toFixed(0), loadLayoutMs: +(loadM.LayoutDuration*1000).toFixed(0), loadStyleMs: +(loadM.RecalcStyleDuration*1000).toFixed(0) };
      R.push(row); console.log(JSON.stringify({ ...row, hookCandidates: undefined }));
      await ctx.close();
    }
  }
  L.fs.writeFileSync(process.env.OUT, JSON.stringify(R, null, 1));
  await browser.close();
})();
