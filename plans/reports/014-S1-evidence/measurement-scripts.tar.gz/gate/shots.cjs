const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s1/node_modules/playwright');
(async()=>{const b=await chromium.launch();const [base,tag,w]=process.argv.slice(2);const vp=w==='390'?{width:390,height:844}:{width:1440,height:900};
const ctx=await b.newContext({viewport:vp});const p=await ctx.newPage(); await p.addInitScript(()=>localStorage.setItem('ntr:welcome-walk-modal:v1',new Date().toISOString()));await p.goto(base+'/',{waitUntil:'load'});await p.waitForTimeout(6000); await p.locator('[role=dialog] [aria-label="Close"]').first().click({timeout:3000}).catch(()=>{}); await p.waitForTimeout(1000);
const H=await p.evaluate(()=>document.documentElement.scrollHeight);for(let y=0;y<H;y+=500){await p.evaluate(y=>scrollTo(0,y),y);await p.waitForTimeout(100);}
for(const s of ['#home-team-section','#home-closing-trust-section','#home-contact-sheet-section','#main-footer']){
 const t=await p.evaluate(s=>{const r=document.querySelector(s).getBoundingClientRect();return [r.top+scrollY,r.height]},s);
 await p.evaluate(y=>scrollTo(0,y),t[0]+Math.max(0,t[1]-vp.height)/2);await p.waitForTimeout(1800);
 await p.screenshot({path:`shot-${tag}-${w}-${s.slice(1)}.png`});console.log(s,t);}
await b.close()})();
