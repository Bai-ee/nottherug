const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s1/node_modules/playwright');
const [,, base, tag] = process.argv;
const SECTIONS = ['#home-team-section','#home-closing-trust-section','#home-contact-sheet-section','#main-footer','#main-nav'];
const TERRA = process.env.TERRA; // rgb string like "rgb(169, 80, 58)"
(async()=>{
 const b=await chromium.launch(); const results=[];
 for (const [vn,vp] of [['1440',{width:1440,height:900}],['390',{width:390,height:844}]]) {
  const ctx=await b.newContext({viewport:vp}); const page=await ctx.newPage(); await page.addInitScript(()=>localStorage.setItem('ntr:welcome-walk-modal:v1',new Date().toISOString()));
  await page.goto(base+'/',{waitUntil:'load'}); await page.waitForTimeout(6000); await page.locator('[role=dialog] [aria-label="Close"]').first().click({timeout:3000}).catch(()=>{}); await page.waitForTimeout(1000);
  // scroll once through to trigger reveals
  const H=await page.evaluate(()=>document.documentElement.scrollHeight);
  for(let y=0;y<H;y+=500){await page.evaluate(y=>window.scrollTo(0,y),y);await page.waitForTimeout(120);}
  const seen=new Set();
  for (const sel of SECTIONS) {
   const top=await page.evaluate(s=>{const e=document.querySelector(s);const r=e.getBoundingClientRect();return {t:r.top+scrollY,h:r.height}},sel);
   for(let y=top.t-vp.height*0.2;y<top.t+top.h;y+=vp.height*0.7){
    await page.evaluate(y=>window.scrollTo(0,Math.max(0,y)),y); await page.waitForTimeout(1600);
    const els=await page.evaluate(({sel,vh,seenArr})=>{
     const root=document.querySelector(sel); const out=[]; const seen=new Set(seenArr);
     const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
     const done=new Set();
     while(w.nextNode()){const n=w.currentNode; if(!n.textContent.trim())continue; const e=n.parentElement; if(done.has(e))continue; done.add(e);
      const cs=getComputedStyle(e); if(cs.visibility==='hidden'||cs.display==='none')continue;
      const rg=document.createRange(); rg.selectNodeContents(n); const r=rg.getBoundingClientRect(); if(r.width<2||r.height<2)continue;
      if(r.top<0||r.bottom>vh)continue;
      let op=1,p=e; while(p){op*=parseFloat(getComputedStyle(p).opacity);p=p.parentElement;} if(op<0.05)continue;
      const path=(e.id?('#'+e.id):e.tagName.toLowerCase()+'.'+[...e.classList].join('.'))+'|'+n.textContent.trim().slice(0,30);
      if(seen.has(path))continue;
      // ancestor selector
      let sp=[],q=e; for(let i=0;i<4&&q&&q!==document.body;i++){sp.unshift(q.id?('#'+q.id):q.tagName.toLowerCase()+(q.classList[0]?'.'+q.classList[0]:''));q=q.parentElement;}
      let bgSelf=null,q2=e; while(q2){const bc=getComputedStyle(q2).backgroundColor; if(bc!=='rgba(0, 0, 0, 0)'){bgSelf=bc;break;} q2=q2.parentElement;}
      out.push({path,sel:sp.join(' > '),text:n.textContent.trim().slice(0,40),color:cs.color,opacity:op,fs:parseFloat(cs.fontSize),fw:parseInt(cs.fontWeight),bgAncestor:bgSelf,rect:{x:r.left,y:r.top,w:r.width,h:r.height}});}
     return out;},{sel,vh:vp.height,seenArr:[...seen]});
    if(!els.length)continue;
    await page.addStyleTag({content:'*{color:transparent !important;text-shadow:none !important;-webkit-text-fill-color:transparent !important}',}).then(h=>h.evaluate(x=>x.id='__hide'));
    const png=await page.screenshot(); 
    await page.evaluate(()=>document.getElementById('__hide').remove());
    const res=await page.evaluate(async({b64,els})=>{
     const img=await createImageBitmap(await (await fetch('data:image/png;base64,'+b64)).blob());
     const c=document.createElement('canvas');c.width=img.width;c.height=img.height;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(img,0,0);
     const sc=img.width/innerWidth;
     const lin=v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)};
     const L=(r,g,b)=>0.2126*lin(r)+0.7152*lin(g)+0.0722*lin(b);
     return els.map(e=>{const m=e.color.match(/[\d.]+/g).map(Number);const a=(m[3]??1)*e.opacity;
      const rx=Math.max(0,Math.floor(e.rect.x*sc)),ry=Math.max(0,Math.floor(e.rect.y*sc)),rw=Math.max(1,Math.min(img.width-rx,Math.floor(e.rect.w*sc))),rh=Math.max(1,Math.min(img.height-ry,Math.floor(e.rect.h*sc)));
      const d=x.getImageData(rx,ry,rw,rh).data; const rat=[];let mr=0,mg=0,mb=0,n=0;
      for(let i=0;i<d.length;i+=16){mr+=d[i];mg+=d[i+1];mb+=d[i+2];n++;}
      mr/=n;mg/=n;mb/=n;
      const tr=m[0]*a+mr*(1-a),tg=m[1]*a+mg*(1-a),tb=m[2]*a+mb*(1-a);const Lt=L(tr,tg,tb);
      for(let i=0;i<d.length;i+=16){const Lb=L(d[i],d[i+1],d[i+2]);const hi=Math.max(Lt,Lb),lo=Math.min(Lt,Lb);rat.push((hi+.05)/(lo+.05));}
      rat.sort((p,q)=>p-q); const Lm=L(mr,mg,mb);
      return {...e,ratioMean:+((Math.max(Lt,Lm)+.05)/(Math.min(Lt,Lm)+.05)).toFixed(2),ratioP5:+rat[Math.floor(rat.length*0.05)].toFixed(2),ratioMin:+rat[0].toFixed(2),bgMean:[mr,mg,mb].map(Math.round).join(',')};});
    },{b64:png.toString('base64'),els});
    for(const r of res){seen.add(r.path);results.push({vp:vn,section:sel,...r});}
   }}
  await page.emulateMedia({}); await ctx.close();
 }
 await b.close(); require('fs').writeFileSync(`contrast-${tag}.json`,JSON.stringify(results,null,1));
 const large=r=>r.fs>=24||(r.fs>=18.66&&r.fw>=700);
 const fail=results.filter(r=>r.ratioMean<(large(r)?3:4.5));
 const terra=results.filter(r=>r.color===TERRA||r.bgAncestor===TERRA);
 console.log(tag,'elements',results.length,'terracotta-related',terra.length,'fail(mean)',fail.length,'fail(p5)',results.filter(r=>r.ratioP5<(large(r)?3:4.5)).length);
})();
