const fs=require('fs');const med=a=>{const s=[...a].sort((x,y)=>x-y);return s[1]};
for(const f of ['mobile','desktop']){
 console.log('\n##',f);
 const R={};
 for(const n of ['base','merged']){R[n]=[1,2,3].map(i=>{const j=JSON.parse(fs.readFileSync(`lh-${n}-${f}-${i}.json`));const a=j.audits,c=j.categories;
  const v=(a['network-requests'].details.items||[]).filter(x=>/\.(mp4|webm)/.test(x.url)).reduce((s,x)=>s+(x.transferSize||0),0);
  const lcpEl=(a['largest-contentful-paint-element'].details?.items?.[0]?.items?.[0]?.node?.selector||'');
  const ph=(a['largest-contentful-paint-element'].details?.items?.[1]?.items||[]).map(x=>x.phase.replace(/ .*/,'')+':'+Math.round(x.timing)).join(' ');
  const cc=(a['color-contrast'].details?.items||[]).map(x=>x.node.selector);
  return {perf:Math.round(c.performance.score*100),lcp:Math.round(a['largest-contentful-paint'].numericValue),tbt:Math.round(a['total-blocking-time'].numericValue),tti:Math.round(a.interactive.numericValue),cls:+a['cumulative-layout-shift'].numericValue.toFixed(3),fcp:Math.round(a['first-contentful-paint'].numericValue),si:Math.round(a['speed-index'].numericValue),a11y:Math.round(c.accessibility.score*100),seo:Math.round(c.seo.score*100),bp:Math.round(c['best-practices'].score*100),kb:Math.round(a['total-byte-weight'].numericValue/1024),vid:Math.round(v/1024),lcpEl,ph,cc,ccscore:a['color-contrast'].score}})}
 for(const n of ['base','merged']){console.log('\n'+n);R[n].forEach((r,i)=>console.log(i+1,JSON.stringify({...r,cc:undefined,lcpEl:undefined,ph:undefined})));
  console.log('median',['perf','lcp','tbt','tti','cls','fcp','si','a11y','seo','bp','kb','vid'].map(k=>k+'='+med(R[n].map(r=>r[k]))).join(' '));
  R[n].forEach((r,i)=>console.log('LCP',i+1,r.lcpEl,'|',r.ph));}
 console.log('\ncolor-contrast items merged:',JSON.stringify(R.merged.map(r=>r.cc)));
 console.log('color-contrast items base:',JSON.stringify(R.base.map(r=>r.cc)));
}
