const L=require('./trace-lib.cjs');(async()=>{const b=await L.chromium.launch();
for(const off of [false,true]){const {ctx,page}=await L.newPage(b,{patchParallax:off});await page.goto(L.URL,{waitUntil:'load'});await L.sleep(3000);await page.evaluate(()=>window.scrollTo(0,3000));await L.sleep(2500);
console.log(off?'off':'on',await page.evaluate(()=>[...document.querySelectorAll('[data-city-parallax]')].filter(e=>/translate|matrix/.test(e.style.transform)).length));await ctx.close();}
await b.close()})();
