const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s1/node_modules/playwright');
const fs=require('fs');const [base,tag]=process.argv.slice(2);
(async()=>{const b=await chromium.launch();const out={};
for(const [vn,vp] of [['390',{width:390,height:844}],['1440',{width:1440,height:900}]]){
 const ctx=await b.newContext({viewport:vp});const p=await ctx.newPage();
 await p.addInitScript(()=>localStorage.setItem('ntr:welcome-walk-modal:v1',new Date().toISOString()));
 await p.goto(base+'/',{waitUntil:'load'});await p.waitForTimeout(6000);
 const H=await p.evaluate(()=>document.documentElement.scrollHeight);for(let y=0;y<H;y+=500){await p.evaluate(y=>scrollTo(0,y),y);await p.waitForTimeout(100);}
 await p.evaluate(()=>scrollTo(0,0));await p.waitForTimeout(2000);
 await p.addScriptTag({path:'/Users/bballi/Documents/Repos/NotTheRug-014-s1/node_modules/axe-core/axe.min.js'});
 const r=await p.evaluate(()=>axe.run(document,{resultTypes:['violations','incomplete']}));
 out[vn]={violations:r.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.map(n=>n.target.join(' ')+' :: '+(n.any[0]?.message||n.all[0]?.message||'').slice(0,120))})),incomplete:r.incomplete.map(v=>({id:v.id,n:v.nodes.length,nodes:v.nodes.slice(0,12).map(n=>n.target.join(' ')+' :: '+(n.any[0]?.message||'').slice(0,100))}))};
 await ctx.close();}
fs.writeFileSync(`axe-${tag}.json`,JSON.stringify(out,null,1));
for(const k in out){console.log(tag,k,'violations',out[k].violations.map(v=>v.id+'x'+v.nodes.length).join(',')||'none','| incomplete',out[k].incomplete.map(v=>v.id+'x'+v.n).join(','))}
await b.close()})();
