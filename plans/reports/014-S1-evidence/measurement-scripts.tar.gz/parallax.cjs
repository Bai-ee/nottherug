const L = require('./trace-lib.cjs');
const R = [];
(async () => {
  const browser = await L.chromium.launch();
  for (const variant of ['on', 'off']) {
    for (let run = 1; run <= 3; run++) {
      const { ctx, page, cdp } = await L.newPage(browser, { patchParallax: variant === 'off' });
      await cdp.send('Performance.enable');
      const m = async () => Object.fromEntries((await cdp.send('Performance.getMetrics')).metrics.map((x) => [x.name, x.value]));
      const tr = await L.startTrace(cdp);
      await page.goto(L.URL, { waitUntil: 'load' });
      await L.sleep(6000);
      const loadM = await m();
      const nArt = await page.evaluate(() => document.querySelectorAll('[data-city-parallax]').length);
      const nArt2 = await page.evaluate(() => document.querySelectorAll('[data-city-parallax-off]').length);
      // scroll measurement: rAF-driven, 8 px/frame, from 600 to 6600 px, 750 frames
      await page.evaluate(() => window.scrollTo(0, 600));
      await L.sleep(1500);
      const m0 = await m();
      const fr = await page.evaluate(() => new Promise((res) => {
        const d = []; let last = performance.now(), y = 600, n = 0;
        function step(t) { d.push(t - last); last = t; y += 8; window.scrollTo(0, y); if (++n < 750) requestAnimationFrame(step); else res(d); }
        requestAnimationFrame(step);
      }));
      const m1 = await m();
      await L.sleep(300);
      const ev = await tr.stop();
      const P = L.parse(ev);
      const frames = fr.slice(1);
      const d = (k) => (m1[k] - m0[k]) * 1000;
      const row = { variant, run, artEls: nArt, artElsPatched: nArt2, frames: frames.length,
        frameMsMean: +(frames.reduce((a, b) => a + b, 0) / frames.length).toFixed(2),
        gt20: frames.filter((x) => x > 20).length, gt33: frames.filter((x) => x > 33.4).length, gt16_7: frames.filter((x) => x > 16.7).length,
        scriptMsPerFrame: +(d('ScriptDuration') / frames.length).toFixed(3), layoutMsPerFrame: +(d('LayoutDuration') / frames.length).toFixed(3),
        styleMsPerFrame: +(d('RecalcStyleDuration') / frames.length).toFixed(3), taskMsPerFrame: +(d('TaskDuration') / frames.length).toFixed(3),
        loadScriptMs: +(loadM.ScriptDuration * 1000).toFixed(0), loadTaskMs: +(loadM.TaskDuration * 1000).toFixed(0), loadLayoutMs: +(loadM.LayoutDuration*1000).toFixed(0), loadStyleMs: +(loadM.RecalcStyleDuration*1000).toFixed(0) };
      // profile: hook callback inclusive time (nodes in the chunk on the line holding the selector)
      if (P.prof) {
        const cands = {};
        for (const n of P.prof.nodes) { const c = n.callFrame; if ((c.url||'').includes('2wdjtc41fusq8') && c.lineNumber >= 0) { const k = `${c.functionName||'(anon)'}@${c.lineNumber+1}:${c.columnNumber+1}`; cands[k] = 1; } }
        row.profileFns = Object.keys(cands).length;
        row.hookCandidates = Object.keys(cands).map((k) => ({ k, ms: +L.inclusive(P, (n) => { const c = n.callFrame; return (c.url||'').includes('2wdjtc41fusq8') && `${c.functionName||'(anon)'}@${c.lineNumber+1}:${c.columnNumber+1}` === k; }).toFixed(1) })).filter((x) => x.ms > 0).sort((a, b) => b.ms - a.ms).slice(0, 14);
        row.longTasks = P.tasks.map((t) => Math.round(t.dur)).sort((a, b) => b - a);
      }
      R.push(row); console.log(JSON.stringify({ ...row, hookCandidates: undefined }));
      await ctx.close();
    }
  }
  L.fs.writeFileSync(__dirname + '/parallax-raw.json', JSON.stringify(R, null, 1));
  await browser.close();
})();
