// Counterfactual (browser-side only, no source edit): the 1400-sample getPointAtLength loop in layoutPawWalk is stubbed in the served chunk.
const L = require('./trace-lib.cjs');
(async () => {
  const browser = await L.chromium.launch();
  for (let run = 1; run <= 3; run++) {
    const { ctx, page, cdp } = await L.newPage(browser);
    await page.route('**/_next/static/chunks/*.js', async (route) => {
      const resp = await route.fetch(); let b = await resp.text();
      b = b.replace('a.getPointAtLength(p*e/1400)', '{x:e,y:e}');
      await route.fulfill({ response: resp, body: b });
    });
    await page.addInitScript(() => { window.__lcp = []; new PerformanceObserver((l) => { for (const e of l.getEntries()) window.__lcp.push([Math.round(e.startTime), e.element?.id]); }).observe({ type: 'largest-contentful-paint', buffered: true }); });
    await page.goto(L.URL, { waitUntil: 'load' }); await L.sleep(4000);
    console.log(run, JSON.stringify(await page.evaluate(() => window.__lcp)));
    await ctx.close();
  }
  await browser.close();
})();
