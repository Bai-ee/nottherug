const L = require('./trace-lib.cjs');
(async () => {
  const browser = await L.chromium.launch();
  for (const v of ['on','off']) {
    const { ctx, page } = await L.newPage(browser, { patchParallax: v === 'off' });
    await page.goto(L.URL, { waitUntil: 'load' }); await L.sleep(4000);
    await page.evaluate(() => window.scrollTo(0, 1500)); await L.sleep(2500);
    console.log(v, await page.evaluate(() => [...document.querySelectorAll('[data-city-parallax]')].map((e) => e.id + ':' + e.style.transform + '|wc=' + e.style.willChange + '|op=' + getComputedStyle(e).opacity).join('\n')));
    await ctx.close();
  }
  await browser.close();
})();
