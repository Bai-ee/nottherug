const L = require('./trace-lib.cjs');
(async () => {
  const browser = await L.chromium.launch();
  for (let run = 1; run <= 3; run++) {
    const { ctx, page, cdp } = await L.newPage(browser);
    const tr = await L.startTrace(cdp);
    await page.goto(L.URL, { waitUntil: 'load' });
    await L.sleep(4000);
    const P = L.parse(await tr.stop());
    // hook code spans chunk 2wdjtc41fusq8.js line 130, cols ~11900-14600 (contains "[data-city-parallax]" at col 13416)
    const inHook = (n) => { const c = n.callFrame; return (c.url || '').includes('2wdjtc41fusq8') && c.lineNumber === 129 && c.columnNumber >= 11900 && c.columnNumber <= 14600; };
    const nodes = P.prof.nodes.filter(inHook).map((n) => `${n.callFrame.functionName || '(anon)'}:${n.callFrame.columnNumber + 1}`);
    console.log(run, 'hook inclusive ms', L.inclusive(P, inHook).toFixed(2), 'fns', [...new Set(nodes)].join(','));
    await ctx.close();
  }
  await browser.close();
})();
