const L = require('./trace-lib.cjs');
const INIT = () => {
  window.__lcp = []; window.__samples = [];
  new PerformanceObserver((l) => { for (const e of l.getEntries()) window.__lcp.push({ t: e.startTime, rt: e.renderTime, lt: e.loadTime, size: e.size, url: e.url, el: e.element ? (e.element.tagName + '#' + e.element.id + '.' + String(e.element.className).slice(0, 40)) : null, text: e.element?.textContent?.slice(0, 40) }); }).observe({ type: 'largest-contentful-paint', buffered: true });
  const q = (s) => document.querySelector(s);
  setInterval(() => {
    const art = q('#hero-cityscape-art'), vis = q('.hero-visual'), eb = q('.hero-eyebrow'), h1 = q('.hero-h1');
    window.__samples.push({ t: Math.round(performance.now()), intro: document.documentElement.dataset.homeIntro || null, overlay: !!q('#home-intro-overlay'),
      art: art ? +getComputedStyle(art).opacity : null, clip: vis ? getComputedStyle(vis).clipPath : null, eyebrow: eb ? +getComputedStyle(eb).opacity : null,
      words: document.querySelectorAll('.hero-h1 .word-inner').length, fonts: document.fonts.status, fontsLoaded: [...document.fonts].filter((f) => f.status === 'loaded').length, fontsTotal: document.fonts.size,
      h1top: h1 ? Math.round(h1.getBoundingClientRect().top) : null });
  }, 50);
};
(async () => {
  const browser = await L.chromium.launch();
  const all = [];
  for (let run = 1; run <= 3; run++) {
    const { ctx, page, cdp } = await L.newPage(browser);
    await page.addInitScript(INIT);
    const tr = await L.startTrace(cdp, true);
    await page.goto(L.URL, { waitUntil: 'load' });
    await L.sleep(5000);
    const data = await page.evaluate(() => ({ lcp: window.__lcp, samples: window.__samples,
      nav: (() => { const n = performance.getEntriesByType('navigation')[0]; return { respStart: n.responseStart, reqStart: n.requestStart, dcl: n.domContentLoadedEventEnd, load: n.loadEventEnd, fetchStart: n.fetchStart }; })(),
      paint: performance.getEntriesByType('paint').map((p) => [p.name, Math.round(p.startTime)]),
      res: performance.getEntriesByType('resource').filter((r) => /img|font|woff|poster|\.webp|\.avif|\.png|\.jpg|\.css/.test(r.name)).map((r) => ({ n: r.name.split('/').slice(-2).join('/').slice(0, 60), start: Math.round(r.startTime), end: Math.round(r.responseEnd), size: r.encodedBodySize })) }));
    const ev = await tr.stop();
    const P = L.parse(ev);
    const shots = ev.filter((e) => e.name === 'Screenshot').sort((a, b) => a.ts - b.ts).map((e) => ({ ms: (e.ts - P.navTs) / 1000, b64: e.args.snapshot }));
    data.shotTimes = shots.map((s) => Math.round(s.ms));
    if (run === 1) {
      // nearest frame at-or-before each 250 ms step to 4000
      for (let t = 0; t <= 4000; t += 250) {
        const c = shots.filter((s) => s.ms <= t).pop(); if (!c) continue;
        L.fs.writeFileSync(`${__dirname}/filmstrip/t${String(t).padStart(4, '0')}ms_frame${Math.round(c.ms)}.jpg`, Buffer.from(c.b64, 'base64'));
      }
    }
    // trace LCP candidates
    data.traceLcp = ev.filter((e) => /largestContentfulPaint/i.test(e.name)).map((e) => ({ n: e.name, ms: Math.round((e.ts - P.navTs) / 1000), size: e.args?.data?.size, type: e.args?.data?.type, nodeName: e.args?.data?.nodeName, url: e.args?.data?.url }));
    all.push(data);
    await ctx.close();
  }
  L.fs.writeFileSync(__dirname + '/lcp-raw.json', JSON.stringify(all, null, 1));
  for (const d of all) console.log(JSON.stringify({ lcp: d.lcp, nav: d.nav, paint: d.paint, trace: d.traceLcp, shots: d.shotTimes.slice(0, 30) }));
  await browser.close();
})();
