const L = require('./trace-lib.cjs');
(async () => {
  const browser = await L.chromium.launch();
  const res = [];
  for (const variant of ['on', 'off']) for (let run = 1; run <= 3; run++) {
    const { ctx, page, cdp } = await L.newPage(browser, { patchParallax: variant === 'off' });
    const tr = await L.startTrace(cdp);
    await page.goto(L.URL, { waitUntil: 'load' });
    await L.sleep(4000);
    const P = L.parse(await tr.stop());
    const t = P.tasks.filter((x) => x.dur > 50).sort((a, b) => a.start - b.start);
    // task containing any sample whose stack has gsap ScrollTrigger refresh/create?  print each task's top-3 self + gsap-ish functions
    console.log(variant, run, t.map((x) => `${Math.round(x.start)}+${Math.round(x.dur)}`).join(' '));
    if (variant === 'on' && run === 1) for (const x of t) console.log('  ', Math.round(x.start), Math.round(x.dur), L.topSelf(P, x.ts, x.ts + x.dur * 1000, 5).join(' | '));
    if (variant === 'off' && run === 1) for (const x of t) console.log('  OFF', Math.round(x.start), Math.round(x.dur), L.topSelf(P, x.ts, x.ts + x.dur * 1000, 5).join(' | '));
    await ctx.close();
  }
  await browser.close();
})();
