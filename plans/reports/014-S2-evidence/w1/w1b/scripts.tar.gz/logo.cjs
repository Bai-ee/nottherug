const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/playwright');
const sharp=require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/sharp');
(async()=>{const b=await chromium.launch();
for (const w of [390,1440]) for (const dpr of [1,2]) {
 const bufs=[];
 for (const port of [3031,3021]) { const ctx=await b.newContext({viewport:{width:w,height:900},deviceScaleFactor:dpr}); const p=await ctx.newPage(); await p.goto('http://localhost:'+port+'/',{waitUntil:'load'}); await p.waitForTimeout(2500);
  const el=p.locator('#nav-logo-img'); bufs.push(await el.screenshot({type:'png'})); await ctx.close(); }
 const a=await sharp(bufs[0]).ensureAlpha().raw().toBuffer({resolveWithObject:true}), c=await sharp(bufs[1]).ensureAlpha().raw().toBuffer();
 let m=0,t=0; for(let i=0;i<a.data.length;i++){const d=Math.abs(a.data[i]-c[i]);if(d>m)m=d;t+=d}
 console.log(w,dpr,a.info.width+'x'+a.info.height,'max',m,'mean',(t/a.data.length).toFixed(3));
}
await b.close()})();
