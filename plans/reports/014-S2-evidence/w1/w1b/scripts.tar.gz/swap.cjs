const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/playwright');
(async()=>{
 const b=await chromium.launch();
 for (const [name,port] of [['preload',3021],['nopreload',3033]]) {
  const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1});
  const p=await ctx.newPage();
  const c=await ctx.newCDPSession(p);
  await c.send('Network.enable');
  await c.send('Network.emulateNetworkConditions',{offline:false,latency:150,downloadThroughput:1.6e6/8,uploadThroughput:750e3/8});
  await c.send('Emulation.setCPUThrottlingRate',{rate:4});
  const t0=Date.now();
  p.goto('http://localhost:'+port+'/').catch(()=>{});
  for (const t of [1500,2500,3500,5500]) {
    await new Promise(r=>setTimeout(r,t-(Date.now()-t0)));
    await p.screenshot({path:`${process.argv[2]}/swap-${name}-${t}.jpg`,type:'jpeg',quality:60});
  }
  await ctx.close();
 }
 await b.close();
})();
