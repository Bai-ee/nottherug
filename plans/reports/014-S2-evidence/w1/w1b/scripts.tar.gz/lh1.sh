#!/bin/zsh
# usage: lh1.sh label url run [desktop]
S=/private/tmp/claude-501/-Users-bballi-Documents-Repos-NotTheRug/2d13b54b-465d-4403-b124-4a9630337cca/scratchpad/w1b
P=""; [ "$4" = desktop ] && P="--preset=desktop"
cd $S/out
npx -y lighthouse@12.8.2 $2 $P --chrome-flags="--headless=new --no-sandbox" --output=json --output-path=$S/out/lh-$1-$3.json --quiet >/dev/null 2>&1
node -e "
const j=require('$S/out/lh-$1-$3.json');const a=j.audits;const rq=a['network-requests'].details.items.filter(r=>r.networkEndTime<(a['largest-contentful-paint'].numericValue));
console.log('$1 $3','perf',Math.round(j.categories.performance.score*100),'LCP',Math.round(a['largest-contentful-paint'].numericValue),'FCP',Math.round(a['first-contentful-paint'].numericValue),'CLS',a['cumulative-layout-shift'].numericValue.toFixed(3),'TBT',Math.round(a['total-blocking-time'].numericValue))"
