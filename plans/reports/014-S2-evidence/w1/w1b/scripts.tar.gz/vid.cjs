const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/playwright');
(async()=>{
 for (const ch of [undefined,'chrome']) {
  let b; try { b=await chromium.launch(ch?{channel:ch}:{}); } catch(e){ console.log(ch,'launch fail',e.message.slice(0,80)); continue; }
  for (const [w,rm] of [[540,'no-preference'],[390,'no-preference'],[1440,'no-preference'],[390,'reduce']]) {
   const ctx=await b.newContext({viewport:{width:w,height:900},reducedMotion:rm});
   const p=await ctx.newPage(); const reqs=[]; const errs=[];
   p.on('request',r=>{if(/hero-mccarren/.test(r.url()))reqs.push(r.url().split('/').pop())});
   p.on('console',m=>{if(m.type()==='error')errs.push(m.text().slice(0,100))}); p.on('pageerror',e=>errs.push('PE '+e.message.slice(0,100)));
   await p.goto('http://localhost:3021/',{waitUntil:'load'}); await p.waitForTimeout(5000);
   const v=await p.evaluate(()=>{const e=document.querySelector('#hero-bg-video');return e&&{t:e.currentTime,paused:e.paused,src:e.currentSrc.split('/').pop(),rs:e.readyState}});
   console.log(ch||'chromium',w,rm,JSON.stringify(v),reqs.join(','),'errors',errs.length,errs.join('|'));
   await ctx.close();
  }
  await b.close();
 }
})();
