const zlib=require('zlib'),fs=require('fs');
for (const f of process.argv.slice(2)) {
  const raw = fs.readFileSync(f); const j = JSON.parse(f.endsWith('.gz')? zlib.gunzipSync(raw): raw);
  const a = j.audits; const lcp = a['largest-contentful-paint'];
  const el = a['largest-contentful-paint-element'];
  const items = el?.details?.items || [];
  const phases = items.find(i=>i.type==='table')?.items || [];
  const insight = a['lcp-breakdown-insight']?.details?.items || a['lcp-breakdown-insight']?.details;
  console.log(f.split('/').pop(), 'perf', Math.round(j.categories.performance.score*100), 'LCP', Math.round(lcp.numericValue), 'FCP', Math.round(a['first-contentful-paint'].numericValue), 'TBT', Math.round(a['total-blocking-time'].numericValue), 'CLS', a['cumulative-layout-shift'].numericValue);
  console.log(' element:', JSON.stringify(items[0]?.items?.[0]?.node?.snippet||'').slice(0,100));
  console.log(' phases:', JSON.stringify(phases.map(p=>[p.phase,Math.round(p.timing)])));
  console.log(' insight:', JSON.stringify(insight)?.slice(0,600));
}
