const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/playwright');
(async () => {
  const b = await chromium.launch();
  for (const port of [3027, 3021]) for (const rm of [false, true]) {
    const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: rm ? 'reduce' : 'no-preference' });
    const p = await ctx.newPage();
    await p.addInitScript(() => { window.__o = []; const t0 = performance.now(); const f = () => { const e = document.getElementById('page-home'); if (e) { const cs = getComputedStyle(e); window.__o.push([Math.round(performance.now() - t0), +(+cs.opacity).toFixed(2), cs.animationName, document.documentElement.dataset.homeIntro || '-', 'ran' + (document.documentElement.hasAttribute('data-home-intro-ran') ? 1 : 0)]); } if (performance.now() - t0 < 2600) requestAnimationFrame(f); }; requestAnimationFrame(f); });
    await p.goto(`http://localhost:${port}/`); await p.waitForTimeout(2800);
    const o = await p.evaluate(() => window.__o);
    const uniq = []; for (const r of o) { const k = r.slice(1).join(','); if (!uniq.length || uniq[uniq.length - 1][1] !== k) uniq.push([r[0], k]); }
    console.log(port, rm ? 'RM' : 'normal', JSON.stringify(uniq.slice(0, 14)));
    await ctx.close();
  }
  await b.close();
})();
