// usage: node slowproxy.cjs listenPort targetPort [rttMs=90] [mbps=40]
const http = require('http');
const [lp, tp, rtt = '90', mbps = '40'] = process.argv.slice(2);
const bytesPerMs = (+mbps * 1e6 / 8) / 1000;
const agent = new http.Agent({ keepAlive: true });
http.createServer((req, res) => {
  const pr = http.request({ host: '127.0.0.1', port: +tp, path: req.url, method: req.method, headers: req.headers, agent }, (up) => {
    setTimeout(() => {
      res.writeHead(up.statusCode, up.headers);
      up.on('data', (chunk) => {
        up.pause();
        res.write(chunk);
        setTimeout(() => up.resume(), chunk.length / bytesPerMs);
      });
      up.on('end', () => res.end());
    }, +rtt);
  });
  pr.on('error', () => { res.statusCode = 502; res.end(); });
  req.pipe(pr);
}).listen(+lp, () => console.log('proxy', lp, '->', tp));
