const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/playwright');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const b = await chromium.launch();
  const out = {};
  for (const [label, port] of [['before', 3027], ['after', 3021]]) {
    for (const [w, h] of [[390, 844], [768, 1024], [1440, 900]]) {
      for (const rm of [false, true]) {
        const ctx = await b.newContext({ viewport: { width: w, height: h }, reducedMotion: rm ? 'reduce' : 'no-preference' });
        const p = await ctx.newPage(); const errs = [];
        p.on('console', (m) => { if (m.type() === 'error' || /hydrat/i.test(m.text())) errs.push(m.text().slice(0, 160)); });
        p.on('pageerror', (e) => errs.push('pageerror ' + String(e).slice(0, 160)));
        await p.goto(`http://localhost:${port}/`, { waitUntil: 'commit' });
        const tag = `${label}_${w}${rm ? '_rm' : ''}`;
        if (!rm) { await sleep(250); await p.screenshot({ path: `png/${tag}_intro250.png` }); await sleep(450); await p.screenshot({ path: `png/${tag}_lift700.png` }); }
        await sleep(rm ? 2500 : 2300);
        await p.screenshot({ path: `png/${tag}_post.png` });
        const info = await p.evaluate(() => ({ intro: document.documentElement.dataset.homeIntro ?? null, overlay: !!document.getElementById('home-intro-overlay'), pageAnim: getComputedStyle(document.getElementById('page-home')).animationName, h1: document.getElementById('hero-headline')?.getBoundingClientRect().top|0, poster: document.getElementById('hero-bg-video')?.poster?.split('/').pop() }));
        out[tag] = { info, errs };
        await ctx.close();
      }
    }
  }
  console.log(JSON.stringify(out, null, 1)); await b.close();
})();
