const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/playwright');
const [url] = process.argv.slice(2);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 412, height: 823 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1.75, ignoreHTTPSErrors: true });
  const page = await ctx.newPage();
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
  await cdp.send('Network.enable'); await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 150, downloadThroughput: 1.6 * 1024 * 1024 / 8, uploadThroughput: 750 * 1024 / 8 });
  await page.addInitScript(() => {
    window.__s = [];
    window.__lcp = [];
    new PerformanceObserver((l) => { for (const e of l.getEntries()) window.__lcp.push([Math.round(e.startTime), (e.url||'').split('/').pop() || e.element?.tagName]); }).observe({ type: 'largest-contentful-paint', buffered: true });
    new PerformanceObserver((l) => { for (const e of l.getEntries()) window.__s.push(['paint', e.name, Math.round(e.startTime)]); }).observe({ type: 'paint', buffered: true });
    setInterval(() => { const q = (s) => document.querySelector(s); const hp = q('.hero-p'); window.__s.push([Math.round(performance.now()), document.documentElement.dataset.homeIntro || '-', !!q('#home-intro-overlay'), hp ? getComputedStyle(hp).opacity : null, document.fonts.status]); }, 100);
  });
  await page.goto(url, { waitUntil: 'load', timeout: 120000 });
  await sleep(4000);
  const d = await page.evaluate(() => ({ lcp: window.__lcp, s: window.__s, res: performance.getEntriesByType('resource').filter(r=>/woff|png|webp|css|js/.test(r.name)).map(r=>[r.name.split('/').pop().slice(0,24), Math.round(r.startTime), Math.round(r.responseEnd), r.renderBlockingStatus||'']).sort((a,b)=>a[2]-b[2]) }));
  console.log(JSON.stringify(d.lcp)); console.log(d.s.filter(x=>x[0]==='paint').join(' | '));
  console.log(d.s.filter(x=>x[0]!=='paint' && x[0] > 1800 && x[0] < 3300).map(x=>x.join(',')).join('\n'));
  console.log(d.res.map(r=>r.join(' ')).join('\n'));
  await browser.close();
})();
