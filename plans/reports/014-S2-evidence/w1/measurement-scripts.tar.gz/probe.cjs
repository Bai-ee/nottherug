// usage: node probe.cjs URL label [throttle=1] runs
const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/playwright');
const [url, label, thr = '1', runs = '3'] = process.argv.slice(2);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const browser = await chromium.launch();
  const out = [];
  for (let i = 0; i < +runs; i++) {
    const ctx = await browser.newContext({ viewport: { width: 412, height: 823 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1.75, ignoreHTTPSErrors: true });
    const page = await ctx.newPage();
    const cdp = await ctx.newCDPSession(page);
    await cdp.send('Emulation.setCPUThrottlingRate', { rate: +(process.env.CPU||4) });
    if (thr === '1') { await cdp.send('Network.enable'); await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 150, downloadThroughput: 1.6 * 1024 * 1024 / 8, uploadThroughput: 750 * 1024 / 8 }); }
    await page.addInitScript(() => {
      window.__lcp = [];
      new PerformanceObserver((l) => { for (const e of l.getEntries()) window.__lcp.push({ t: Math.round(e.startTime), rt: Math.round(e.renderTime), lt: Math.round(e.loadTime), size: e.size, url: (e.url||'').split('/').pop(), el: e.element ? e.element.tagName + '#' + e.element.id : null }); }).observe({ type: 'largest-contentful-paint', buffered: true });
    });
    const reqs = []; if (process.env.NOVIDEO) await page.route(/hero-mccarren-(540|1080)/, (r) => r.abort());
    page.on('response', (r) => reqs.push(r.url().split('/').slice(-1)[0].slice(0, 40)));
    await page.goto(url, { waitUntil: 'load', timeout: 120000 });
    await sleep(6000);
    const d = await page.evaluate(() => ({ lcp: window.__lcp, nav: (() => { const n = performance.getEntriesByType('navigation')[0]; return { ttfb: Math.round(n.responseStart), load: Math.round(n.loadEventEnd) }; })(), fcp: Math.round(performance.getEntriesByType('paint').find(p=>p.name==='first-contentful-paint')?.startTime||0) }));
    d.final = d.lcp[d.lcp.length - 1];
    out.push(d); console.log(label, JSON.stringify(d));
    await ctx.close();
  }
  require('fs').writeFileSync(__dirname + `/out/probe-${label}.json`, JSON.stringify(out, null, 1));
  await browser.close();
})();
