import sys,json
for line in sys.stdin:
    label,_,rest=line.partition(' ')
    try:
        d=json.loads(rest)
        print(label,'FINAL',d['final']['t'],d['final']['url'] or 'text',d['final']['el'],'| seq',[(x['t'],(x['url'] or 'txt')[:12]) for x in d['lcp']],'fcp',d['fcp'])
    except Exception as e: print('ERR',line[:150])
