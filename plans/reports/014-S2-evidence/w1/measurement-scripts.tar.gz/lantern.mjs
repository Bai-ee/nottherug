const LH = process.env.HOME + '/.npm/_npx/8003d8991b0d346b/node_modules/lighthouse/core';
const {loadArtifacts} = await import(LH + '/lib/asset-saver.js');
const {LanternLargestContentfulPaint} = await import(LH + '/computed/metrics/lantern-largest-contentful-paint.js');
const {defaultSettings} = await import(LH + '/config/constants.js');
const dir = process.argv[2];
const art = await loadArtifacts(dir);
const settings = {...defaultSettings, throttlingMethod: 'simulate'};
const ctx = {computedCache: new Map(), settings};
const data = {trace: art.Trace, devtoolsLog: art.DevtoolsLog, gatherContext: art.GatherContext, settings, URL: art.URL, SourceMaps: art.SourceMaps, simulator: undefined};
const res = await LanternLargestContentfulPaint.request(data, ctx);
console.log('timing', Math.round(res.timing), 'opt', Math.round(res.optimisticEstimate.timeInMs), 'pess', Math.round(res.pessimisticEstimate.timeInMs));
for (const [name, est] of [['OPT', res.optimisticEstimate], ['PESS', res.pessimisticEstimate]]) {
  const rows = [...est.nodeTimings.entries()].map(([n, t]) => ({ n, end: t.endTime, start: t.startTime }));
  rows.sort((a, b) => b.end - a.end);
  console.log(name, rows.length, 'nodes; latest:');
  for (const r of rows.slice(0, 40)) console.log('  ', Math.round(r.start), Math.round(r.end), r.n.type, r.n.type === 'network' ? r.n.request.url.split('/').pop().slice(0, 40) + ' ' + r.n.request.resourceType + '/' + r.n.request.priority + ' ' + Math.round(r.n.request.transferSize / 1024) + 'KB' : 'cpu');
}
