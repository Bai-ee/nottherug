#!/bin/zsh
# usage: lhp.sh label [url] [n]
S=/private/tmp/claude-501/-Users-bballi-Documents-Repos-NotTheRug/2d13b54b-465d-4403-b124-4a9630337cca/scratchpad/w1
U=${2:-http://localhost:3121/}; N=${3:-3}
cd $S/out; rm -rf latest-run
for i in $(seq 1 $N); do npx -y lighthouse@12.8.2 $U --chrome-flags="--headless=new --no-sandbox" --output=json --output-path=$S/out/lh-$1-$i.json --quiet >/dev/null 2>&1; done
for i in $(seq 1 $N); do node -e "
const j=require('$S/out/lh-$1-$i.json');const a=j.audits;const it=a['largest-contentful-paint-element'].details.items;const t=it.find(x=>x.items&&x.items[0]&&x.items[0].phase);const o=a.metrics.details.items[0];
console.log('$1 $i','perf',Math.round(j.categories.performance.score*100),'LCP',Math.round(a['largest-contentful-paint'].numericValue),'FCP',Math.round(a['first-contentful-paint'].numericValue),'TBT',Math.round(a['total-blocking-time'].numericValue),'|',t.items.map(p=>p.phase+':'+Math.round(p.timing)).join(' '),'| obsLCP',o.observedLargestContentfulPaint,'obsFCP',o.observedFirstContentfulPaint)"; done
