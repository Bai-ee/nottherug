// usage: node h2proxy.cjs listenPort targetPort
const http2 = require('http2'), http = require('http'), fs = require('fs');
const [lp, tp] = process.argv.slice(2);
const agent = new http.Agent({ keepAlive: true, maxSockets: 64 });
http2.createSecureServer({ key: fs.readFileSync(__dirname + '/key.pem'), cert: fs.readFileSync(__dirname + '/cert.pem'), allowHTTP1: true }, (req, res) => {
  const headers = { ...req.headers }; for (const k of Object.keys(headers)) if (k.startsWith(':')) delete headers[k]; headers.host = 'localhost:' + tp;
  const pr = http.request({ host: '127.0.0.1', port: +tp, path: req.url, method: req.method, headers, agent }, (up) => {
    const h = { ...up.headers }; delete h.connection; delete h['transfer-encoding']; delete h['keep-alive'];
    res.writeHead(up.statusCode, h); up.pipe(res);
  });
  pr.on('error', () => { res.statusCode = 502; res.end(); });
  req.pipe(pr);
}).listen(+lp, () => console.log('h2', lp, '->', tp));
