const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w1/node_modules/playwright');
const [url, cpu = '1', thr = '0'] = process.argv.slice(2);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 412, height: 823 }, isMobile: true, hasTouch: true, deviceScaleFactor: 1.75, ignoreHTTPSErrors: true, reducedMotion: process.env.RM ? 'reduce' : 'no-preference' });
  const page = await ctx.newPage(); const cdp = await ctx.newCDPSession(page);
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: +cpu });
  if (thr === '1') { await cdp.send('Network.enable'); await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: 150, downloadThroughput: 1.6 * 1024 * 1024 / 8, uploadThroughput: 750 * 1024 / 8 }); }
  if (process.env.NOCLIP) await page.addInitScript(() => { new MutationObserver(() => { const v = document.querySelector('.hero-visual'); if (v && v.style.clipPath && v.style.clipPath !== 'none') v.style.clipPath = 'none'; }).observe(document, { subtree: true, attributes: true, childList: true, attributeFilter: ['style'] }); });
  if (process.env.NOOVERLAY) await page.addInitScript(() => { const st = document.createElement('style'); st.textContent = '#home-intro-overlay{display:none!important}'; document.addEventListener('DOMContentLoaded', () => document.head.appendChild(st)); const t = setInterval(() => { if (document.head) { document.head.appendChild(st); clearInterval(t); } }, 1); });
  await page.addInitScript(() => { new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeName === 'SOURCE') window.__attach = Math.round(performance.now()); }).observe(document, { subtree: true, childList: true }); });
  if (process.env.NOOCCLUDE) await page.addInitScript(() => { const st = document.createElement('style'); st.textContent = '#home-intro-overlay{background-color: rgba(247,241,227,.99) !important}'; const t = setInterval(() => { if (document.head) { document.head.appendChild(st); clearInterval(t); } }, 1); });
  if (process.env.POKE) await page.addInitScript((ms) => { setTimeout(() => { const i = document.getElementById('hero-poster-image'); if (i) { i.style.transform = 'translate(0px, 0px)'; } }, ms); }, +process.env.POKE);
  if (process.env.NOFADE) await page.addInitScript(() => { const st = document.createElement('style'); st.textContent = "html[data-home-intro='loading'] #page-home{animation:none!important}"; const t = setInterval(() => { if (document.head) { document.head.appendChild(st); clearInterval(t); } }, 1); });
  const events = []; cdp.on('Tracing.dataCollected', (d) => events.push(...d.value));
  const done = new Promise((r) => cdp.once('Tracing.tracingComplete', r));
  await cdp.send('Tracing.start', { categories: 'loading,devtools.timeline,blink.user_timing,disabled-by-default-devtools.timeline,disabled-by-default-devtools.screenshot', transferMode: 'ReportEvents' });
  await page.goto(url, { waitUntil: 'load' }); await sleep(3500);
  await cdp.send('Tracing.end'); await done;
  const nav = events.filter((e) => e.name === 'navigationStart').sort((a, b) => a.ts - b.ts).pop();
  const t0 = nav.ts;
  for (const e of events.filter((e) => /largestContentfulPaint::Candidate|firstContentfulPaint|firstPaint$|LayoutShift/.test(e.name)).sort((a,b)=>a.ts-b.ts))
    {const d=e.args?.data||{};console.log(Math.round((e.ts - t0) / 1000), e.name.replace('largestContentfulPaint::',''), d.nodeName||'', d.size||'', d.type||'', d.imageLoadEnd?Math.round(d.imageLoadEnd):'');}
  if (process.env.TASKS) { for (const e of events.filter((e) => e.ph === 'X' && /^(RunTask|Paint|Commit|PrePaint|Layout|UpdateLayoutTree|EvaluateScript|FunctionCall|v8.compile|ImageDecodeTask|Decode Image|Draw LazyPixelRef)$/.test(e.name) && (e.dur >= (e.name==='RunTask'?25000:2000)) ).sort((a,b)=>a.ts-b.ts)) { const st=(e.ts-t0)/1000; if (st<1000) console.log('  ', Math.round(st), e.name, Math.round(e.dur/1000)+'ms', (e.args?.data?.url||'').split('/').pop()||''); } }
  if (process.env.SHOTS) { const fs=require('fs'); const sh=events.filter(e=>e.name==='Screenshot').sort((a,b)=>a.ts-b.ts); sh.forEach((e,i)=>{ const ms=Math.round((e.ts-t0)/1000); if (ms<1500) fs.writeFileSync(__dirname+'/shots/'+process.env.SHOTS+'_'+String(ms).padStart(5,'0')+'.jpg', Buffer.from(e.args.snapshot,'base64')); }); }
console.log('attach at', await page.evaluate(() => window.__attach)); await browser.close();
})();
