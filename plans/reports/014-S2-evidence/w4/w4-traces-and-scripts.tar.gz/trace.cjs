const { createRequire } = require('module');
const req = createRequire('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w4/package.json');
const { chromium } = req('playwright');
const [,, url, mode, label] = process.argv;
(async () => {
  const b = await chromium.launch();
  const mobile = mode === 'mobile';
  const ctx = await b.newContext(mobile ? { viewport:{width:390,height:844}, deviceScaleFactor:2, isMobile:true, hasTouch:true, userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile' } : { viewport:{width:1440,height:900} });
  const page = await ctx.newPage();
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Network.enable');
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: 4 });
  // slow 4G: 1.6 Mbps down, 150ms RTT
  await cdp.send('Network.emulateNetworkConditions', { offline:false, latency:150, downloadThroughput:1.6*1024*1024/8, uploadThroughput:750*1024/8 });
  const t0 = Date.now();
  const reqs = {};
  cdp.on('Network.requestWillBeSent', e => { if (/\/video\//.test(e.request.url)) reqs[e.requestId] = { url:e.request.url.replace(/^.*\/video\//,''), range:e.request.headers.Range||e.request.headers.range||'', t:Date.now()-t0, bytes:0 }; });
  cdp.on('Network.responseReceived', e => { const r=reqs[e.requestId]; if(r){ r.status=e.response.status; r.tResp=Date.now()-t0; r.cr=e.response.headers['content-range']||e.response.headers['Content-Range']||''; }});
  cdp.on('Network.dataReceived', e => { const r=reqs[e.requestId]; if(r){ r.bytes+=e.encodedDataLength||e.dataLength; if(/webm|mp4/.test(r.url)) (global.cum=global.cum||[]).push([Date.now()-t0,r.bytes]); }});
  cdp.on('Network.loadingFinished', e => { const r=reqs[e.requestId]; if(r){ r.tEnd=Date.now()-t0; r.enc=e.encodedDataLength; }});
  await page.addInitScript(() => { new PerformanceObserver(l => { for (const x of l.getEntries()) window.__lcp = x.startTime; }).observe({type:'largest-contentful-paint', buffered:true}); });
  await page.goto(url, { waitUntil:'load' });
  const tLoad = Date.now()-t0;
  const marks = [];
  for (let i=0;i<20;i++){ await page.waitForTimeout(1000);
    const s = await page.evaluate(()=>{const v=document.querySelector('video');return v?{src:v.currentSrc.replace(/^.*\/video\//,''),rs:v.readyState,t:+v.currentTime.toFixed(1),paused:v.paused, buffered:v.buffered.length?+v.buffered.end(v.buffered.length-1).toFixed(1):0}:null});
    marks.push(s); }
  const lcp = await page.evaluate(()=>window.__lcp);
  const cum=global.cum||[];const before=cum.filter(c=>c[0]<=lcp).pop();console.log(JSON.stringify({label,mode,tLoad,lcp:Math.round(lcp),videoBytesAtLCP:before?before[1]:0,reqStart:Object.values(reqs).filter(r=>/webm|mp4/.test(r.url)).map(r=>r.t),reqs:Object.values(reqs).map(r=>({...r,total:r.enc})),state:[marks[0],marks[4],marks[9],marks[19]]},null,1));
  await b.close();
})();
