const { createRequire } = require('module');
const req = createRequire('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w4/package.json');
const { chromium } = req('playwright');
(async()=>{
 const b = await chromium.launch({channel:'chrome'});
 const p = await b.newPage();
 await p.goto('http://localhost:3034/book');
 const r = await p.evaluate(async()=>{
  const out={};
  for (const f of ['hero-mccarren-540.mp4','hero-mccarren-540-v2.mp4']) {
   const v=document.createElement('video'); v.muted=true; v.src='/video/'+f; document.body.appendChild(v);
   await new Promise(res=>{v.onloadedmetadata=res; v.onerror=res;});
   let ok=false; try{await v.play();ok=true}catch(e){out[f+'_err']=String(e)}
   await new Promise(r=>setTimeout(r,1500));
   out[f]={dur:v.duration,w:v.videoWidth,h:v.videoHeight,t:+v.currentTime.toFixed(2),ok,err:v.error&&v.error.code};
  }
  return out;});
 console.log(JSON.stringify(r));
 await b.close();
})();
