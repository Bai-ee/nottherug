const fs=require("fs");const b=require("./contrast-base.json"),a=require("./contrast-after.json");
const large=r=>r.fs>=24||(r.fs>=18.66&&r.fw>=700);const req=r=>large(r)?3:4.5;
const key=x=>x.route+"|"+x.vp+"|"+x.path;
const worst=arr=>{const m=new Map();for(const x of arr){const o=m.get(key(x));if(!o||x.ratioMean<o.ratioMean)m.set(key(x),x)}return m};
const bm=worst(b),am=worst(a);
const keys=[...new Set([...bm.keys(),...am.keys()])];
const rows=[];let st={uniq:keys.length,bf:0,af:0};
for(const k of keys){const x=bm.get(k),y=am.get(k);const ref=y||x;const r=req(ref);
 const bfail=x&&!x.disabled&&x.ratioMean<r, afail=y&&!y.disabled&&y.ratioMean<r;
 if(bfail)st.bf++; if(afail)st.af++;
 if(!bfail&&!afail)continue;
 rows.push({route:ref.route,vp:ref.vp,sel:ref.sel,text:ref.text.replace(/\|/g,"/"),fs:ref.fs,fw:ref.fw,ab:x?.alpha,aa:y?.alpha,rb:x?.ratioMean,ra:y?.ratioMean,pb:x?.ratioP5,pa:y?.ratioP5,req:r,bp:x?(bfail?"FAIL":"pass"):"-",ap:y?(afail?"FAIL":"pass"):"-"});}
rows.sort((p,q)=>(p.route+p.vp).localeCompare(q.route+q.vp)||p.sel.localeCompare(q.sel));
let md=`# S2/W3 contrast before -> after\n\nRows = elements that failed before or after (mean-pixel ratio; p5 = 5th-percentile pixel ratio). Method: text hidden (inline !important transparent, transition none), real rendered pixels under each text rect sampled, ratio = blended fg vs mean bg. Required: 4.5 body, 3 large (>=24px, or >=18.66px bold). Disabled controls excluded.\n\nScanned (rows): before ${b.length}, after ${a.length}; unique element keys ${st.uniq}.\nFailing (all rows): before 586, after 70. Failing (unique keys, worst case): before ${st.bf}, after ${st.af}.\n\n| route | vp | selector | text | size/wt | fg alpha b->a | ratio b->a | p5 b->a | req | before | after |\n|---|---|---|---|---|---|---|---|---|---|---|\n`;
for(const r of rows)md+=`| ${r.route} | ${r.vp} | ${r.sel.split(" > ").slice(-3).join(" > ")} | ${r.text} | ${r.fs}/${r.fw} | ${r.ab??"-"} -> ${r.aa??"-"} | ${r.rb??"-"} -> ${r.ra??"-"} | ${r.pb??"-"} -> ${r.pa??"-"} | ${r.req} | ${r.bp} | ${r.ap} |\n`;
fs.writeFileSync("/Users/bballi/Documents/Repos/NotTheRug-014-s2-w3/plans/reports/014-S2-evidence/w3/contrast-before-after.md",md);console.log(st,rows.length);
