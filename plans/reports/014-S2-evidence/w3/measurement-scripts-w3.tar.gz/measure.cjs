const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w3/node_modules/playwright');
const fs = require('fs');
const [base, tag, routesArg] = process.argv.slice(2);
const ROUTES = (routesArg || '/,/about,/safety,/neighborhoods/williamsburg,/reviews,/book,/signup').split(',');
const VPS = [['390', { width: 390, height: 844 }], ['768', { width: 768, height: 1024 }], ['1440', { width: 1440, height: 900 }]];
(async () => {
  const b = await chromium.launch(); const results = [];
  for (const route of ROUTES) for (const [vn, vp] of VPS) {
    const ctx = await b.newContext({ viewport: vp, reducedMotion: 'no-preference' }); const page = await ctx.newPage();
    await page.addInitScript(() => localStorage.setItem('ntr:welcome-walk-modal:v1', new Date().toISOString()));
    await page.goto(base + route, { waitUntil: 'load' }); await page.waitForTimeout(route === '/' ? 6000 : 2500);
    await page.locator('[role=dialog] [aria-label="Close"]').first().click({ timeout: 1500 }).catch(() => {});
    const H = await page.evaluate(() => document.documentElement.scrollHeight);
    for (let y = 0; y < H; y += 500) { await page.evaluate(y => window.scrollTo(0, y), y); await page.waitForTimeout(100); }
    const seen = new Set();
    for (let y = 0; y < H; y += vp.height * 0.7) {
      await page.evaluate(y => window.scrollTo(0, y), y); await page.waitForTimeout(1300);
      const els = await page.evaluate(({ vh, vw, seenArr }) => {
        const out = []; const seen = new Set(seenArr); const done = new Set();
        const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        while (w.nextNode()) {
          const n = w.currentNode; if (!n.textContent.trim()) continue; const e = n.parentElement; if (!e || done.has(e)) continue; done.add(e);
          if (['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(e.tagName)) continue;
          const cs = getComputedStyle(e); if (cs.visibility === 'hidden' || cs.display === 'none') continue;
          const rg = document.createRange(); rg.selectNodeContents(n); const r = rg.getBoundingClientRect(); if (r.width < 2 || r.height < 2) continue;
          if (r.top < 0 || r.bottom > vh || r.left < 0 || r.right > vw) continue;
          let op = 1, p = e, hidden = false; while (p) { const c = getComputedStyle(p); op *= parseFloat(c.opacity); if (c.visibility === 'hidden') hidden = true; p = p.parentElement; } if (op < 0.05 || hidden) continue;
          if (e.closest('[aria-hidden="true"]') && false) continue;
          const path = (e.id ? ('#' + e.id) : e.tagName.toLowerCase() + '.' + [...e.classList].join('.')) + '|' + n.textContent.trim().slice(0, 30);
          if (seen.has(path)) continue;
          let sp = [], q = e; for (let i = 0; i < 4 && q && q !== document.body; i++) { sp.unshift(q.id ? ('#' + q.id) : q.tagName.toLowerCase() + (q.classList[0] ? '.' + q.classList[0] : '')); q = q.parentElement; }
          let sec = e.closest('section,footer,nav,header,main'); const secId = sec ? (sec.id || sec.tagName.toLowerCase()) : '';
          const bb = e.getBoundingClientRect();
          out.push({ path, sec: secId, sel: sp.join(' > '), text: n.textContent.trim().slice(0, 40), color: cs.color, opacity: op, fs: parseFloat(cs.fontSize), fw: parseInt(cs.fontWeight), disabled: !!e.closest('[disabled],[aria-disabled="true"]'), ariaHidden: !!e.closest('[aria-hidden="true"]'), rect: { x: r.left, y: r.top, w: r.width, h: r.height }, box: { x: bb.left + scrollX, y: bb.top + scrollY, w: bb.width, h: bb.height } });
        }
        return out;
      }, { vh: vp.height, vw: vp.width, seenArr: [...seen] });
      if (!els.length) continue;
      await page.evaluate(() => { window.__hid = []; document.querySelectorAll('body *').forEach(e => { const has = [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim()); if (!has) return; window.__hid.push([e, e.getAttribute('style')]); e.style.setProperty('color', 'transparent', 'important'); e.style.setProperty('-webkit-text-fill-color', 'transparent', 'important'); e.style.setProperty('text-shadow', 'none', 'important'); e.style.setProperty('transition', 'none', 'important'); }); return new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))); });
      const png = await page.screenshot();
      await page.evaluate(() => { for (const [e, s] of window.__hid) { if (s === null) e.removeAttribute('style'); else e.setAttribute('style', s); } window.__hid = []; });
      const res = await page.evaluate(async ({ b64, els }) => {
        const img = await createImageBitmap(await (await fetch('data:image/png;base64,' + b64)).blob());
        const c = document.createElement('canvas'); c.width = img.width; c.height = img.height; const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0);
        const sc = img.width / innerWidth;
        const lin = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4) };
        const L = (r, g, b) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
        return els.map(e => {
          const m = e.color.match(/[\d.]+/g).map(Number); const a = (m[3] ?? 1) * e.opacity;
          const rx = Math.max(0, Math.floor(e.rect.x * sc)), ry = Math.max(0, Math.floor(e.rect.y * sc)), rw = Math.max(1, Math.min(img.width - rx, Math.floor(e.rect.w * sc))), rh = Math.max(1, Math.min(img.height - ry, Math.floor(e.rect.h * sc)));
          const d = x.getImageData(rx, ry, rw, rh).data; const rat = []; let mr = 0, mg = 0, mb = 0, n = 0;
          for (let i = 0; i < d.length; i += 16) { mr += d[i]; mg += d[i + 1]; mb += d[i + 2]; n++; }
          mr /= n; mg /= n; mb /= n;
          const tr = m[0] * a + mr * (1 - a), tg = m[1] * a + mg * (1 - a), tb = m[2] * a + mb * (1 - a); const Lt = L(tr, tg, tb);
          for (let i = 0; i < d.length; i += 16) { const Lb = L(d[i], d[i + 1], d[i + 2]); const hi = Math.max(Lt, Lb), lo = Math.min(Lt, Lb); rat.push((hi + .05) / (lo + .05)); }
          rat.sort((p, q) => p - q); const Lm = L(mr, mg, mb);
          return { ...e, alpha: +a.toFixed(3), ratioMean: +((Math.max(Lt, Lm) + .05) / (Math.min(Lt, Lm) + .05)).toFixed(2), ratioP5: +rat[Math.floor(rat.length * 0.05)].toFixed(2), bgMean: [mr, mg, mb].map(Math.round).join(',') };
        });
      }, { b64: png.toString('base64'), els });
      for (const r of res) { seen.add(r.path); results.push({ route, vp: vn, ...r }); }
    }
    await ctx.close(); console.log(tag, route, vn, results.length);
  }
  await b.close(); fs.writeFileSync(`${process.env.OUT || '.'}/contrast-${tag}.json`, JSON.stringify(results));
  const large = r => r.fs >= 24 || (r.fs >= 18.66 && r.fw >= 700);
  const real = results.filter(r => !r.disabled);
  console.log(tag, 'total', results.length, 'fail(mean)', real.filter(r => r.ratioMean < (large(r) ? 3 : 4.5)).length, 'fail(p5)', real.filter(r => r.ratioP5 < (large(r) ? 3 : 4.5)).length);
})();
