const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w3/node_modules/playwright');
const fs=require('fs');const [base,tag]=process.argv.slice(2);
const ROUTES=['/','/about','/safety','/neighborhoods/williamsburg','/reviews','/book','/signup'];
(async()=>{const b=await chromium.launch();const out={};
for(const route of ROUTES)for(const [vn,vp] of [['390',{width:390,height:844}],['1440',{width:1440,height:900}]]){
 const ctx=await b.newContext({viewport:vp});const p=await ctx.newPage();
 await p.addInitScript(()=>localStorage.setItem('ntr:welcome-walk-modal:v1',new Date().toISOString()));
 await p.goto(base+route,{waitUntil:'load'});await p.waitForTimeout(route==='/'?6000:2500);
 const H=await p.evaluate(()=>document.documentElement.scrollHeight);for(let y=0;y<H;y+=500){await p.evaluate(y=>scrollTo(0,y),y);await p.waitForTimeout(100);}
 await p.evaluate(()=>scrollTo(0,0));await p.waitForTimeout(1500);
 await p.addScriptTag({path:'/Users/bballi/Documents/Repos/NotTheRug-014-s2-w3/node_modules/axe-core/axe.min.js'});
 const r=await p.evaluate(()=>axe.run(document,{runOnly:['color-contrast'],resultTypes:['violations','incomplete']}));
 out[route+' '+vn]={violations:r.violations.flatMap(v=>v.nodes.map(n=>n.target.join(' ')+' :: '+(n.any[0]?.message||'').slice(0,110))),incomplete:r.incomplete.reduce((a,v)=>a+v.nodes.length,0)};
 console.log(tag,route,vn,'viol',out[route+' '+vn].violations.length,'incomplete',out[route+' '+vn].incomplete);
 await ctx.close();}
fs.writeFileSync(`axe-${tag}.json`,JSON.stringify(out,null,1));await b.close()})();
