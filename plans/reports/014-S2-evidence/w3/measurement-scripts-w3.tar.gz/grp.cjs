const r=require('./contrast-'+process.argv[2]+'.json');
const large=r=>r.fs>=24||(r.fs>=18.66&&r.fw>=700);
const f=r.filter(x=>!x.disabled&&x.ratioMean<(large(x)?3:4.5));
const g={};
for(const x of f){const k=x.color+' | bg '+x.bgMean.split(',').map(v=>Math.round(v/20)*20).join(',')+' | '+x.sel.split(' > ').slice(-2).join(' > ').replace(/\.[\w-]+/g,m=>m).slice(0,70);(g[k]??=[]).push(x)}
const arr=Object.entries(g).sort((a,b)=>b[1].length-a[1].length);
for(const [k,v] of arr.slice(0,+process.argv[3]||60))console.log(v.length,k,'| e.g.',v[0].route,v[0].vp,JSON.stringify(v[0].text),v[0].fs,v[0].ratioMean,v[0].bgMean)
console.log(arr.length,'groups')
