const { chromium } = require('/Users/bballi/Documents/Repos/NotTheRug-014-s2-w3/node_modules/playwright');
const [base,tag,outdir]=process.argv.slice(2);
(async()=>{const b=await chromium.launch();
for(const route of ['/','/book','/about'])for(const [vn,vp] of [['390',{width:390,height:844}],['768',{width:768,height:1024}],['1440',{width:1440,height:900}]]){
 const ctx=await b.newContext({viewport:vp});const p=await ctx.newPage();
 await p.addInitScript(()=>localStorage.setItem('ntr:welcome-walk-modal:v1',new Date().toISOString()));
 await p.goto(base+route,{waitUntil:'load'});await p.waitForTimeout(route==='/'?6000:2500);
 const H=await p.evaluate(()=>document.documentElement.scrollHeight);for(let y=0;y<H;y+=400){await p.evaluate(y=>scrollTo(0,y),y);await p.waitForTimeout(120);}
 await p.evaluate(()=>scrollTo(0,0));await p.waitForTimeout(1500);
 // footer + closing viewport shots: full page is too tall, so capture bottom viewport and top viewport
 const name=(route==='/'?'home':route.slice(1))+'-'+vn;
 await p.screenshot({path:`${outdir}/${tag}-${name}-top.png`});
 await p.evaluate(()=>scrollTo(0,document.documentElement.scrollHeight));await p.waitForTimeout(1500);
 await p.screenshot({path:`${outdir}/${tag}-${name}-bottom.png`});
 if(route==='/'){const t=await p.evaluate(()=>{const e=document.querySelector('#home-closing-trust-section');return e.getBoundingClientRect().top+scrollY});
  await p.evaluate(y=>scrollTo(0,y),t);await p.waitForTimeout(1500);await p.screenshot({path:`${outdir}/${tag}-${name}-closing-trust.png`});}
 await ctx.close();}
await b.close()})();
