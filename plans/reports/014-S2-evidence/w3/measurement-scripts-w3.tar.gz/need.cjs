const r=require('./contrast-'+process.argv[2]+'.json');
const lin=v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)};
const L=(r,g,b)=>0.2126*lin(r)+0.7152*lin(g)+0.0722*lin(b);
const large=r=>r.fs>=24||(r.fs>=18.66&&r.fw>=700);
const ratioAt=(x,a)=>{const m=x.color.match(/[\d.]+/g).map(Number);const bg=x.bgMean.split(',').map(Number);const c=[0,1,2].map(i=>m[i]*a+bg[i]*(1-a));const Lt=L(...c),Lb=L(...bg);return (Math.max(Lt,Lb)+.05)/(Math.min(Lt,Lb)+.05)};
const g={};
for(const x of r){ if(x.disabled)continue; const t=large(x)?3:4.5; if(x.ratioMean>=t)continue;
 const m=x.color.match(/[\d.]+/g).map(Number); if(!(m[0]>=230))continue; // light text
 let a=m[3]??1; const base=a; let need=null; for(let a2=base;a2<=1.0001;a2+=0.01){ if(ratioAt(x,a2)>=t){need=a2;break} }
 const k=x.color; (g[k]??=[]).push({need,x});}
for(const [k,v] of Object.entries(g)){const unmet=v.filter(e=>e.need===null);const needs=v.filter(e=>e.need!==null).map(e=>e.need).sort((a,b)=>a-b);
 console.log(k,'n',v.length,'unmet@1.0',unmet.length,'need p50',needs[Math.floor(needs.length/2)]?.toFixed(2),'p95',needs[Math.floor(needs.length*.95)]?.toFixed(2),'max',needs[needs.length-1]?.toFixed(2));
 for(const u of unmet.slice(0,4))console.log('   unmet',u.x.route,u.x.vp,u.x.text,u.x.bgMean,u.x.ratioMean)}
