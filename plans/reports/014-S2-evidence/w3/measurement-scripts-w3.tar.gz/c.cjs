const lin=v=>{v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)};
const hx=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));
const L=c=>0.2126*lin(c[0])+0.7152*lin(c[1])+0.0722*lin(c[2]);
const R=(a,b)=>{const x=L(a),y=L(b);return ((Math.max(x,y)+.05)/(Math.min(x,y)+.05)).toFixed(2)};
const [fg, ...bgs]=process.argv.slice(2);
console.log(fg,bgs.map(b=>b+'='+R(hx(fg),b.split(',').map(Number))).join('  '));
